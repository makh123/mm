<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class collaboration extends Model
{
    protected $guarded=[];
}
